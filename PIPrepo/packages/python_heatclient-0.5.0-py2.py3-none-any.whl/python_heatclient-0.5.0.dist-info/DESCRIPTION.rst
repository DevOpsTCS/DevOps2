=================
python-heatclient
=================

OpenStack Orchestration API Client Library

This is a client library for Heat built on the Heat orchestration API. It
provides a Python API (the ``heatclient`` module) and a command-line tool
(``heat``).

* Free software: Apache license
* Documentation: http://docs.openstack.org/developer/python-heatclient
* Source: http://git.openstack.org/cgit/openstack/python-heatclient
* Bugs: http://bugs.launchpad.net/python-heatclient



