OpenStack Sphinx Extensions
===========================

Theme and extension support for Sphinx documentation from the
OpenStack project.

* Free software: Apache License, Version 2.0
* Documentation: http://docs.openstack.org/developer/oslosphinx
* Source: http://git.openstack.org/cgit/openstack/oslosphinx
* Bugs: http://bugs.launchpad.net/oslosphinx



