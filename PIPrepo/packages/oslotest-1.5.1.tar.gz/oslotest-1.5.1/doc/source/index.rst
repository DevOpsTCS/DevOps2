Welcome to oslotest's documentation!
====================================

OpenStack test framework and test fixtures.

Contents
========

.. toctree::
   :maxdepth: 2

   installation
   api
   testing
   features
   resources
   contributing
   history

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
