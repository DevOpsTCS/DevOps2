==========
 oslotest
==========

OpenStack test framework and test fixtures.

* Free software: Apache license
* Documentation: http://docs.openstack.org/developer/oslotest
* Source: http://git.openstack.org/cgit/openstack/oslotest
* Bugs: http://bugs.launchpad.net/oslotest
