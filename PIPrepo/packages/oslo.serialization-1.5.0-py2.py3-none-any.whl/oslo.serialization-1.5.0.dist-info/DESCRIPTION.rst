====================
 oslo.serialization
====================

.. image:: https://pypip.in/version/oslo.serialization/badge.svg
    :target: https://pypi.python.org/pypi/oslo.serialization/
    :alt: Latest Version

.. image:: https://pypip.in/download/oslo.serialization/badge.svg?period=month
    :target: https://pypi.python.org/pypi/oslo.serialization/
    :alt: Downloads

The oslo.serialization library provides support for representing objects
in transmittable and storable formats, such as JSON and MessagePack.

* Free software: Apache license
* Documentation: http://docs.openstack.org/developer/oslo.serialization
* Source: http://git.openstack.org/cgit/openstack/oslo.serialization
* Bugs: http://bugs.launchpad.net/oslo.serialization



