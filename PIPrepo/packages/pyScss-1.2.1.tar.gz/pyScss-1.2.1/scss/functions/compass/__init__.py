# Global cache of image sizes, shared between sprites and images libraries.
_image_size_cache = {}
