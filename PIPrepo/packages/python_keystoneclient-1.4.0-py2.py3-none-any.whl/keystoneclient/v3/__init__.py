
from keystoneclient.v3.client import Client  # noqa


__all__ = [
    'client',
]
