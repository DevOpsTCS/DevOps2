==========
Whoosh API
==========

.. toctree::
    :glob:
    :maxdepth: 1

    **
